//
//  DeliveryTableViewCell3.swift
//  Food Delivery Task 16
//
//  Created by Naved Khan on 13/04/23.
//

import UIKit

class DeliveryTableViewCell3: UITableViewCell {

    @IBOutlet weak var tagText1: UILabel!
    @IBOutlet weak var tagText2: UILabel!
    @IBOutlet weak var tagText4: UILabel!
    @IBOutlet weak var tagTotal: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
