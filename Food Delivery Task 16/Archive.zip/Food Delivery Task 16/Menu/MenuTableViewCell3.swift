//
//  MenuTableViewCell3.swift
//  Food Delivery Task 16
//
//  Created by Naved Khan on 10/04/23.
//

import UIKit

class MenuTableViewCell3: UITableViewCell {

    @IBOutlet weak var insideText: UILabel!
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
