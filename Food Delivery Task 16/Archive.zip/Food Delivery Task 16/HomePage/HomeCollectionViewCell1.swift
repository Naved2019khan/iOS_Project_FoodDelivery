//
//  HomeCollectionViewCell1.swift
//  Food Delivery Task 16
//
//  Created by Naved Khan on 14/04/23.
//

import UIKit

class HomeCollectionViewCell1: UICollectionViewCell {
    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.layer.cornerRadius = 10
        // Initialization code
    }

}
