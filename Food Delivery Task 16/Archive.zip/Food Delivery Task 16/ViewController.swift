//
//  ViewController.swift
//  Food Delivery Task 16
//
//  Created by Naved Khan on 10/04/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

